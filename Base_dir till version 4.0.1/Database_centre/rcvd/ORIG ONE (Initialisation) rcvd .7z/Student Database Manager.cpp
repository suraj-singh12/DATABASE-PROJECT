/*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

  * ::: Description :::
  :* ::> Student Database Manager
  ::* ::> Designed And Programed By* :: SP MAURYA ::
  :::* ::> Feel Secure With The Concept of Object Oriented Program
  ::::* ::> It Made By Using Classes And Functions

  * ::: Features :::
  :* ::> Add Student Details
  ::* ::> See Student Details
  :::* ::> Edit Student Details
  ::::* ::> Delete Student Details
  :::::* ::> If You Forgot Your Password! Then You Can Change It With The Help Of Master Password

  * ::: Advanced Features :::
  :* ::> It Has Artificial Intelligence
  ::* ::> Full Secured
  :::* ::> It Gives You Independent Access To Your Database
  ::::* ::> The Students Can Only Add And See Their Database i.e. They Need Master Password To Change Their Database!
  :::::* ::> The Master Password Cannot Be Changed By User Only The Developer Can Change It

:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::HERES::THE::STARTING::OF::CODING:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

#include<iostream>      // It Prints Output And Takes Input And ETC... ETC...
#include<string.h>      // It Perform The Required Operations For The Strings...
#include<fstream>       // It Perform File Handling Tasks... It Includes IFSTREAM And OFSTREAM
#include<ctype.h>       // It Is Used In This Program For TOUPPER Function
#include<iomanip>       // It Is Used For Printing A Number Of Spaces OR Other Characters( basically for using function setw() & setfill() )
#include<stdio.h>       // It Is Used For GETS(); Functions To Input A String
#include<windows.h>     // It Contains console commands And In This Program It Is Mainly Used For Changing The Cursor Position With The Help Of Coordinates
#include<dir.h>         // It Perform Directory Related Tasks
#include<conio.h>       // It Is Used For GETCH(); and _getch();
#include<math.h>        // It IS Used For Mathematical Operations
using namespace std;
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

// DEFINITION SECTION
#define Console GetStdHandle(STD_OUTPUT_HANDLE)
// Coordinate Variable
COORD CursorPosition;
COORD BufferSize;
COORD WindowSize;
// Structure For Font
typedef struct FONT
{
    ULONG  Size;
    DWORD  Font;
    COORD  FontSize;
    UINT   FontFamily;
    UINT   FontWeight;
    WCHAR  FaceName[LF_FACESIZE];
}FONT,*PFONT;
extern "C" {BOOL WINAPI SetCurrentConsoleFontEx(HANDLE ConsoleOutput,BOOL MaximumWindow,PFONT);}

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

class student
{
private:// Data Variables
        char name[32],fathers_name[32],mothers_name[32],clas[16],section[16],roll_number[16];
        char admission_date[16],admission_number[16],birth_date[16],blood_group[5],gender[8];
        char address[64],cast[16],phone_number[16],email[32],char_height[16],char_weight[16];
        char char_result_10[5],char_result_12[5],unique_id[16];

        // Data Variables for Temporary Use
        char temp_name[64],temp_fathers_name[64],temp_mothers_name[64],temp_clas[64],temp_section[64];
        char temp_roll_number[64],temp_admission_date[64],temp_admission_number[64],temp_birth_date[64];
        char temp_blood_group[64],temp_gender[64],temp_address[64],temp_cast[64],temp_phone_number[64];
        char temp_email[64],temp_char_height[64],temp_char_weight[64],temp_char_result_10[64];
        char temp_char_result_12[64],temp_unique_id[64],temp_bmi[64];

        // Other Variables
        char mast_pass[16],fname[64],fname_old[64],fcode[64],fcode_old[64],password[16],passcode[16],char_bmi[16];

        // Floating Point Variables
        float height,weight,bmi;

public: // These are the Main Functions
        void display();             // It Displays the Main Program Logo
        void get_data();            // It is the Student Details Inputer
        void get_details();         // It Inputs the Student Details required to Login, Hence to Access their Data
        void delete_data();         // It Deletes the Student database as per the User Requirement
        void data_edit_start();           // It helps to Edit a Particular Entry of the Student
        void forgot_password();     // It helps to Change the Password when a Student Forgot his/her Password

        // These Functions are for Artificial Intelligence
        // These Functions are used in this program give Artificial Intelligence
        // They prevents wrong Input from User
        int digit(char*);
        int alpha(char*);
        int cast_temp(char*);
        int date_temp(char*);
        int unique_id_temp(char*);
        int digit_temp(char*);
        int blood_temp(char*);
        int gender_temp(char);
        int email_temp(char*);
        int result_temp(char*);

        // These are the Functions that are called from the Main Functions
           // For get_data();
        void background_process();
        void store_data();
        void make_file(char* ch,char* chr);

           // For get_details();
        void show_details();
        char* get_file(char*);

           // For data_edit_start();
        void edit_data();

        // These are Form Converters
        char* upper_case(char*);
        char* upper(char*);
        char* underscore(char*);
        char* no_underscore(char*);
        float CharToNum(char*);

        // It is a Cursor Teleporter
        void gotoXY(int,int);

        // It Change the Font Size
        void Font(int);

        // It Change the Window Size
        void Window(int,int);

        // It Change the Buffer Screen Size
        void Buffer(int,int);

        // It Stores the Password
        void store_password();

        // Others
        char* get_pass(char*,int,int,int);
        void frename();
        void store_bmi();
        void MakeDocument();
};

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

int main()                          // Here is the Main Function Starts
{
    system("color 70");
    int Choice;
    student object;                 //Creating Object
    system("cls");

    object.Font(16);
    object.display();
    cout<<setfill(' ')<<"\n";
    cout<<setw(5)<<""<<":::::: What You Want To Do!"<<endl;
    cout<<setw(10)<<""<<"1.To Add Student Details"<<endl;
    cout<<setw(10)<<""<<"2.To See Student Details"<<endl;
    cout<<setw(10)<<""<<"3.To Delete Student Details"<<endl;
    cout<<setw(10)<<""<<"4.To Edit Student Details"<<endl;
    cout<<setw(10)<<""<<"5.Forgotten Password!"<<endl;
    cout<<setw(10)<<""<<"0.EXIT!!"<<endl;
    cout<<setw(5)<<""<<":::::: Enter Your Choice Number: ";
    cin>>Choice;

    system("cls");
    object.display();
    switch(Choice)
    {
        case  1: object.get_data();
                 break;
        case  2: object.get_details();
                 break;
        case  3: object.delete_data();
                 break;
        case  4: object.data_edit_start();
                 break;
        case  5: object.forgot_password();
                 break;
        case  0: return 0;
        default: cout<<"\n"<<setfill(' ')<<setw(5)<<""<<"::::: Invalid Choice! :::::\n\n\n\n\n\n\n\n\n\n";
                 system("timeout 3");
                 main();
    }
    if(Choice==1||Choice==2||Choice==4)
    {
        cout<<"\n\t::::: Loading! :::::\n";
        object.MakeDocument();
        system("timeout>nul 2 /nobreak");   // It Stops the Program Execution For A While Without Displaying the Timer
    }
    main();                         // Calling The Main Functions To Continue The Program
}                                   // Here is the Main Function Ends

//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

// It is the Definition of gotoXY() Functions
void student::gotoXY(int x,int y)
{
    CursorPosition.X = x;                               // Defining "X" coordinate variable
    CursorPosition.Y = y;                               // Defining "Y" coordinate variable
    SetConsoleCursorPosition(Console,CursorPosition);   // Finally It Teleports the Cursor
}

//It is the Programs Main Heading Or We Can Say LOGO
void student::display()
{
    system("cls");
    cout<<setw(51)<<setfill(':')<<':'<<endl;
    cout<<setw(10)<<setfill(' ')<<""<<endl;
    cout<<setw(10)<<setfill(' ')<<' '<<"   Student Database Manager     "<<endl;
    cout<<setw(10)<<setfill(' ')<<' '<<"::::: Made By* Sp Maurya :::::\n"<<endl;
    cout<<setw(51)<<setfill(':')<<':'<<endl;
}

// Takes the Student Data from the USER
void student::get_data()            // It is the Starting of Option 1
{
    int i=8;
    cout<<setfill(' ')<<endl;
    cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;

    cout<<setw(7)<<"|> "<<"Student's Name"<<setw(17)<<":> ";gets(name);
    while(name[0]=='\0'){gotoXY(38,i);gets(name);}
    i++;

    cout<<setw(7)<<"|> "<<"Class(If Passed Out Type 13)"<<setw(1)<<":> ";gets(clas);
    while(clas[0]=='\0'||digit(clas)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(clas);}
    i++;
/***********************************************************************************/
    if(CharToNum(clas)<13){
    cout<<setw(7)<<"|> "<<"Section"<<setw(24)<<":> ";gets(section);
    while(section[0]=='\0'||alpha(section)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(section);}
    i++;}
/***********************************************************************************/
    cout<<setw(7)<<"|> "<<"Roll Number"<<setw(20)<<":> ";gets(roll_number);
    while(roll_number[0]=='\0'||digit(roll_number)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(roll_number);}
    i++;

    cout<<setw(7)<<"|> "<<"Father's Name"<<setw(18)<<":> ";gets(fathers_name);
    while(fathers_name[0]=='\0'){gotoXY(38,i);gets(fathers_name);}
    i++;

    cout<<setw(7)<<"|> "<<"Mother's Name"<<setw(18)<<":> ";gets(mothers_name);
    while(mothers_name[0]=='\0'){gotoXY(38,i);gets(mothers_name);}
    i++;

    cout<<setw(7)<<"|> "<<"Gender(M/F)"<<setw(20)<<":> ";gets(gender);
    while(gender_temp(gender[0])==1)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(gender);}
    i++;

    cout<<setw(7)<<"|> "<<"Blood Group"<<setw(20)<<":> ";gets(blood_group);
    while(blood_group[0]=='\0'||blood_temp(blood_group)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(blood_group);}
    i++;

    cout<<setw(7)<<"|> "<<"Admission Number"<<setw(15)<<":> ";gets(admission_number);
    while(admission_number[0]=='\0'||digit(admission_number)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(admission_number);}
    i++;

    cout<<setw(7)<<"|> "<<"Admission Date(DD/MM/YYYY)"<<setw(5)<<":> ";gets(admission_date);
    while(admission_date[0]=='\0'||date_temp(admission_date)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(admission_date);}
    i++;

    cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";gets(birth_date);
    while(birth_date[0]=='\0'||date_temp(birth_date)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(birth_date);}
    i++;

    cout<<setw(7)<<"|> "<<"Address"<<setw(24)<<":> ";gets(address);
    while(address[0]=='\0'){gotoXY(38,i);gets(address);}
    i++;

    cout<<setw(7)<<"|> "<<"Category(SC/ST/OBC/GENERAL)"<<setw(4)<<":> ";gets(cast);
    while(cast[0]=='\0'||cast_temp(cast)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(cast);}
    i++;

    cout<<setw(7)<<"|> "<<"Phone Number"<<setw(19)<<":> ";gets(phone_number);
    while(strlen(phone_number)<10||digit(phone_number)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(phone_number);}
    i++;

    cout<<setw(7)<<"|> "<<"Email ID"<<setw(23)<<":> ";gets(email);
    while(strlen(email)<12||email_temp(email)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(email);}
    i++;

    cout<<setw(7)<<"|> "<<"Height(in Centimeters)"<<setw(9)<<":> ";gets(char_height);
    while(char_height[0]=='\0'||digit_temp(char_height)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(char_height);}
    i++;

    cout<<setw(7)<<"|> "<<"Weight(in Kilograms)"<<setw(11)<<":> ";gets(char_weight);
    while(char_weight[0]=='\0'||digit_temp(char_weight)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(char_weight);}
    i++;

    cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";gets(unique_id);
    while(unique_id[0]=='\0'||unique_id_temp(unique_id)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(unique_id);}
    i++;

    if(CharToNum(clas)>10){
    cout<<setw(7)<<"|> "<<"Result of 10th(in %age)"<<setw(8)<<":> ";gets(char_result_10);
    while(char_result_10[0]=='\0'||result_temp(char_result_10)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(char_result_10);}
    i++;}

    if(CharToNum(clas)>12){
    cout<<setw(7)<<"|> "<<"Result of 12th(in %age)"<<setw(8)<<":> ";gets(char_result_12);
    while(char_result_12[0]=='\0'||result_temp(char_result_12)>0)
    {gotoXY(38,i);cout<<setw(100)<<"";gotoXY(38,i);gets(char_result_12);}
    i++;}

    cout<<setw(7)<<"|> "<<"Password (OF Length 8)"<<setw(9)<<":> ";
    strcpy(password,get_pass(password,8,38,i));

    // Calling for the Next Step, i.e. Background Process
    background_process();
}

// It is some Background Process
void student::background_process()
{
    // Storing the Names of the Files
    strcpy(temp_name,"name");
    strcpy(temp_fathers_name,"fathers_name");
    strcpy(temp_mothers_name,"mothers_name");
    strcpy(temp_clas,"clas");
    strcpy(temp_section,"section");
    strcpy(temp_roll_number,"roll_number");
    strcpy(temp_admission_date,"admission_date");
    strcpy(temp_admission_number,"admission_number");
    strcpy(temp_birth_date,"birth_date");
    strcpy(temp_blood_group,"blood_group");
    strcpy(temp_gender,"gender");
    strcpy(temp_address,"address");
    strcpy(temp_cast,"cast");
    strcpy(temp_phone_number,"phone_number");
    strcpy(temp_email,"email");
    strcpy(temp_char_height,"char_height");
    strcpy(temp_char_weight,"char_weight");
    strcpy(temp_char_result_10,"char_result_10");
    strcpy(temp_char_result_12,"char_result_12");
    strcpy(temp_unique_id,"unique_id");

    // Converting the Data to their Standard Form
    strcpy(name,upper_case(name));
    strcpy(fathers_name,upper_case(fathers_name));
    strcpy(mothers_name,upper_case(mothers_name));
    strcpy(blood_group,upper(blood_group));
    strcpy(address,upper_case(address));
    strcpy(cast,upper(cast));
    strcpy(section,upper(section));

    if(CharToNum(clas)>12)
    {
        strcpy(clas,"Passed_Out");      // If the Student is PASSED OUT
        strcpy(section,"Passed_Out");
    }

    // Adding the Full Form of Gender
    if(gender[0]=='m'||gender[0]=='M'){strcpy(gender,"Male");}
    else strcpy(gender,"Female");

    // First Check Whether the Folder exist or not then Create
    if(!mkdir("database"));

    // Creating Sub-Folder Name
    strcpy(fname,"database\\");
    strcat(fname,unique_id);
    strcat(fname,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(fname,temp);

    // It sends the Process to the Next Step where the files are going to be stored
    store_data();
}

// It Create Files with File Extension ".sdms" And Stores the Student Data in them
void student::store_data()
{
    // First Check Whether the Folder already exist or not then Create the
    // Folder named as the created name in background_process() earlier
    if(!mkdir(fname));

    // Replacing the Spaces with Underscores
    strcpy(name,underscore(name));
    strcpy(fathers_name,underscore(fathers_name));
    strcpy(mothers_name,underscore(mothers_name));
    strcpy(address,underscore(address));

    // Creating Files And Storing the Student Data
    make_file(temp_name,name);
    make_file(temp_fathers_name,fathers_name);
    make_file(temp_mothers_name,mothers_name);
    make_file(temp_clas,clas);
    make_file(temp_section,section);
    make_file(temp_roll_number,roll_number);
    make_file(temp_admission_date,admission_date);
    make_file(temp_admission_number,admission_number);
    make_file(temp_birth_date,birth_date);
    make_file(temp_blood_group,blood_group);
    make_file(temp_gender,gender);
    make_file(temp_address,address);
    make_file(temp_cast,cast);
    make_file(temp_phone_number,phone_number);
    make_file(temp_email,email);
    make_file(temp_char_height,char_height);
    make_file(temp_char_weight,char_weight);
    if(CharToNum(clas)>10){
    make_file(temp_char_result_10,char_result_10);}
    if(CharToNum(clas)>12){
    make_file(temp_char_result_12,char_result_12);}
    make_file(temp_unique_id,unique_id);

    store_bmi();

    // It stores the Password Separately in Secured Folder
    store_password();
}           // It is the End of Option 1

// It Logins the Students to their Data to Access It
void student::get_details()             // It is the Starting of Option 2
{
    cout<<setfill(' ')<<endl;
    cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;

    cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";gets(unique_id);
    while(unique_id[0]=='\0'||unique_id_temp(unique_id)>0)
    {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(unique_id);}

    cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";gets(birth_date);
    while(birth_date[0]=='\0'||date_temp(birth_date)>0)
    {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(birth_date);}

    cout<<setw(7)<<"|> "<<"Password (OF Length 8)"<<setw(9)<<":> ";
    strcpy(password,get_pass(password,8,38,10));

    // Creating the File Location of the already Stored Password
    strcpy(fcode,"secured\\");
    strcat(fcode,unique_id);
    strcat(fcode,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
        // Replacing "/" with "_" of the Date of Birth
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(fcode,temp);
    strcat(fcode,".sdms");

    // Now Reading that Password from created Location
    ifstream file_in(fcode);
    file_in>>passcode;
    file_in.close();

    // It Checks whether the Password is correct or not
    if(strcmp(password,passcode)==0||strcmp(password,"madebysp")==0)
    {   // Storing Names of File as before

        strcpy(temp_name,"name");
        strcpy(temp_fathers_name,"fathers_name");
        strcpy(temp_mothers_name,"mothers_name");
        strcpy(temp_clas,"clas");
        strcpy(temp_section,"section");
        strcpy(temp_roll_number,"roll_number");
        strcpy(temp_admission_date,"admission_date");
        strcpy(temp_admission_number,"admission_number");
        strcpy(temp_blood_group,"blood_group");
        strcpy(temp_gender,"gender");
        strcpy(temp_address,"address");
        strcpy(temp_cast,"cast");
        strcpy(temp_phone_number,"phone_number");
        strcpy(temp_email,"email");
        strcpy(temp_char_height,"char_height");
        strcpy(temp_char_weight,"char_weight");
        strcpy(temp_char_result_10,"char_result_10");
        strcpy(temp_char_result_12,"char_result_12");
        strcpy(temp_bmi,"bmi");

        // Reading Student Data from already stored Data
        strcpy(name,get_file(temp_name));
        strcpy(fathers_name,get_file(temp_fathers_name));
        strcpy(mothers_name,get_file(temp_mothers_name));
        strcpy(clas,get_file(temp_clas));
        strcpy(section,get_file(temp_section));
        strcpy(roll_number,get_file(temp_roll_number));
        strcpy(admission_date,get_file(temp_admission_date));
        strcpy(admission_number,get_file(temp_admission_number));
        strcpy(blood_group,get_file(temp_blood_group));
        strcpy(gender,get_file(temp_gender));
        strcpy(address,get_file(temp_address));
        strcpy(cast,get_file(temp_cast));
        strcpy(phone_number,get_file(temp_phone_number));
        strcpy(email,get_file(temp_email));
        strcpy(char_height,get_file(temp_char_height));
        strcpy(char_weight,get_file(temp_char_weight));
        if(CharToNum(clas)>10){
        strcpy(char_result_10,get_file(temp_char_result_10));}
        if(CharToNum(clas)>12){
        strcpy(char_result_12,get_file(temp_char_result_12));}
        strcpy(char_bmi,get_file(temp_bmi));
        bmi=CharToNum(char_bmi);

        // Replacing the "_" with
        strcpy(name,no_underscore(name));
        strcpy(fathers_name,no_underscore(fathers_name));
        strcpy(mothers_name,no_underscore(mothers_name));
        strcpy(address,no_underscore(address));

        if(strcmp(clas,"Passed_Out")==0)
        {
            strcpy(clas,"Passed Out");
            strcpy(section,"Passed Out");
        }

        // It will send the Process to the Next Step which Display the Accessed Data
        show_details();
    }
    else {cout<<"\n"<<setw(5)<<""<<"::::: Incorrect Details! :::::\n\n\n\n\n\n\n\n\n\n";system("timeout 3");}
}

// It Displays the Student Details
void student::show_details()
{
    system("cls");
    display();
    cout<<setfill(' ')<<endl;

    cout<<setw(7)<<"|> "<<"Student's Name"<<setw(17)<<":> ";cout<<name<<endl;
    cout<<setw(7)<<"|> "<<"Class"<<setw(26)<<":> ";cout<<clas;
    // Adding the Suffix to Class
    if(clas[0]=='1'&&clas[1]=='\0') {cout<<"st\n";}
    else if(clas[0]=='2'&&clas[1]=='\0') {cout<<"nd\n";}
    else if(clas[0]=='3'&&clas[1]=='\0') {cout<<"rd\n";}
    else {if(CharToNum(clas)<13)cout<<"th\n";}
    cout<<setw(7)<<"|> "<<"Section"<<setw(24)<<":> ";cout<<section<<endl;
    cout<<setw(7)<<"|> "<<"Roll Number"<<setw(20)<<":> ";cout<<roll_number<<endl;
    cout<<setw(7)<<"|> "<<"Father's Name"<<setw(18)<<":> ";cout<<fathers_name<<endl;
    cout<<setw(7)<<"|> "<<"Mother's Name"<<setw(18)<<":> ";cout<<mothers_name<<endl;
    cout<<setw(7)<<"|> "<<"Gender(M/F)"<<setw(20)<<":> ";cout<<gender<<endl;
    cout<<setw(7)<<"|> "<<"Blood Group"<<setw(20)<<":> ";cout<<blood_group<<endl;
    cout<<setw(7)<<"|> "<<"Admission Number"<<setw(15)<<":> ";cout<<admission_number<<endl;
    cout<<setw(7)<<"|> "<<"Admission Date(DD/MM/YYYY)"<<setw(5)<<":> ";cout<<admission_date<<endl;
    cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";cout<<birth_date<<endl;
    cout<<setw(7)<<"|> "<<"Address"<<setw(24)<<":> ";cout<<address<<endl;
    cout<<setw(7)<<"|> "<<"Category(SC/ST/OBC/GENERAL)"<<setw(4)<<":> ";cout<<cast<<endl;
    cout<<setw(7)<<"|> "<<"Phone Number"<<setw(19)<<":> ";cout<<phone_number<<endl;
    cout<<setw(7)<<"|> "<<"Email ID"<<setw(23)<<":> ";cout<<email<<endl;
    cout<<setw(7)<<"|> "<<"Height(in Centimeters)"<<setw(9)<<":> ";cout<<char_height<<endl;
    cout<<setw(7)<<"|> "<<"Weight(in Kilograms)"<<setw(11)<<":> ";cout<<char_weight<<endl;
    cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";cout<<unique_id<<endl;
    cout<<setw(7)<<"|> "<<"BMI(Body Mass Index)"<<setw(11)<<":> ";cout<<char_bmi<<" ";
    if(bmi>0&&bmi<18.5){cout<<"(UNDER-WEIGHT)\n";}
    else if(bmi>=18.5&&bmi<25){cout<<"(HEALTHY)\n";}
    else if(bmi>=25&&bmi<30){cout<<"(OVER-WEIGHT)\n";}
    else {cout<<"(OBESE)\n";}
    if(CharToNum(clas)>10){
    cout<<setw(7)<<"|> "<<"Result of 10th(in %age)"<<setw(8)<<":> ";cout<<char_result_10<<endl;}
    if(CharToNum(clas)>12){
    cout<<setw(7)<<"|> "<<"Result of 12th(in %age)"<<setw(8)<<":> ";cout<<char_result_12<<endl;}
    cout<<"\n";
    system("pause");
}           // It is the End of Option 2

// It Deletes the Student Data as per the user requirement
void student::delete_data()             // It is the Starting of Option 3
{
    char ch;
    cout<<setfill(' ')<<endl;
    cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;

    cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";gets(unique_id);
    while(unique_id[0]=='\0'||unique_id_temp(unique_id)>0)
    {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(unique_id);}

    cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";gets(birth_date);
    while(birth_date[0]=='\0'||date_temp(birth_date)>0)
    {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(birth_date);}

    cout<<setw(7)<<"|> "<<"Password (OF Length 8)"<<setw(9)<<":> ";
    strcpy(password,get_pass(password,8,38,10));

    // Creating the File Location of the already Stored Password
    strcpy(fcode,"secured\\");
    strcat(fcode,unique_id);
    strcat(fcode,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
        // Replacing "/" with "_" of the Date of Birth
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(fcode,temp);
    strcat(fcode,".sdms");

    // Now Reading that Password from created Location
    ifstream file_in(fcode);
    file_in>>passcode;
    file_in.close();

    if(strcmp(password,passcode)==0||strcmp(password,"madebysp")==0)
    {
        if(strcmp(password,"madebysp")!=0)
        {
            cout<<setfill(' ');
            cout<<"\n\n"<<setw(5)<<":::::"<<" Enter The Master Password (OF Length 8) :> ";
            strcpy(mast_pass,get_pass(mast_pass,8,49,12));
        }
        if(strcmp(password,"madebysp")==0||strcmp(mast_pass,"madebysp")==0)
        {
            cout<<"\n\n"<<setw(5)<<":::::"<<" Are You Sure, You Want To Delete! (Y/N) :> ";
            cin>>ch;
            if(ch=='y'||ch=='Y')
            {
                char del[64];
                char temp[16];
                int i=0;
                strcpy(del,"RD /S /Q ");
                strcat(del,"database\\");
                strcat(del,unique_id);
                strcat(del,"_");
                strcpy(temp,birth_date);
                while(temp[i]!='\0')
                {
                    if(temp[i]=='/'){temp[i]='_';}
                    i++;
                }
                strcat(del,temp);
                system(del);

                i=0;
                strcpy(del,"Del /F /Q ");
                strcat(del,"secured\\");
                strcat(del,unique_id);
                strcat(del,"_");
                strcpy(temp,birth_date);
                while(temp[i]!='\0')
                {
                    if(temp[i]=='/'){temp[i]='_';}
                    i++;
                }
                strcat(del,temp);
                strcat(del,".sdms");
                system(del);
                cout<<"\tStudent Data Deleted Successfully!\n\n\n";system("timeout 3");
            }
            else {cout<<"\tStudent Data Not Deleted!\n\n\n";system("timeout 3");}
        }
        else {cout<<"\n"<<setw(5)<<""<<"Incorrect Master Password! Contact the Software Developer for Help...\n\n\n";system("timeout 3");}
    }
    else {cout<<"\n"<<setw(5)<<""<<"::::: Incorrect Details! :::::\n\n\n";system("timeout 3");}
}           // It is the End of Option 3

void student::data_edit_start()           // It is the Starting of Option 4
{
    cout<<setfill(' ')<<endl;
    cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;

    cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";gets(unique_id);
    while(unique_id[0]=='\0'||unique_id_temp(unique_id)>0)
    {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(unique_id);}

    cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";gets(birth_date);
    while(birth_date[0]=='\0'||date_temp(birth_date)>0)
    {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(birth_date);}

    cout<<setw(7)<<"|> "<<"Password (OF Length 8)"<<setw(9)<<":> ";
    strcpy(password,get_pass(password,8,38,10));

    // Creating the File Location of the already Stored Password
    strcpy(fcode,"secured\\");
    strcat(fcode,unique_id);
    strcat(fcode,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
        // Replacing "/" with "_" of the Date of Birth
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(fcode,temp);
    strcat(fcode,".sdms");

    // Now Reading that Password from created Location
    ifstream file_in(fcode);
    file_in>>passcode;
    file_in.close();

    if(strcmp(password,passcode)==0||strcmp(password,"madebysp")==0)
    {
        if(strcmp(password,"madebysp")!=0)
        {
            cout<<setfill(' ')<<endl;
            cout<<"\n"<<setw(5)<<":::::"<<" Enter The Master Password (OF Length 8) :> ";
            strcpy(mast_pass,get_pass(mast_pass,8,49,12));
        }
        if(strcmp(password,"madebysp")==0||strcmp(mast_pass,"madebysp")==0)
        {
            strcpy(fname_old,"database\\");
            strcat(fname_old,unique_id);
            strcat(fname_old,"_");
            char temp[16];
            int i=0;
            strcpy(temp,birth_date);
            while(temp[i]!='\0')
            {
                if(temp[i]=='/'){temp[i]='_';}
                i++;
            }
            strcat(fname_old,temp);

            strcpy(fcode_old,"secured\\");
            strcat(fcode_old,unique_id);
            strcat(fcode_old,"_");
            strcat(fcode_old,temp);
            strcat(fcode_old,".sdms");

            edit_data();        // It will send the Process to the Next Step to Edit
        }
        else cout<<"\n\n\n"<<setw(5)<<""<<"Incorrect Master Password! Contact the Software Developer for Help...\n\n\n";
        system("timeout 3");
    }
    else {cout<<"\n\n\n"<<setw(5)<<""<<"::::: Incorrect Details! :::::\n\n\n";system("timeout 3");}
}

// It can change the Particular Entries of the Student Data
void student::edit_data()
{
    int Choice;
    display();
    cout<<setfill(' ')<<endl;
    cout<<setw(7)<<":::"<<"What You Want To Change!"<<endl;
    cout<<setw(7)<<" 1."<<"Student's Name"<<endl;
    cout<<setw(7)<<" 2."<<"Class & Section(If Passed Out Type Class \"13\")"<<endl;
    cout<<setw(7)<<" 3."<<"Roll Number"<<endl;
    cout<<setw(7)<<" 4."<<"Father's Name"<<endl;
    cout<<setw(7)<<" 5."<<"Mother's Name"<<endl;
    cout<<setw(7)<<" 6."<<"Gender(M/F)"<<endl;
    cout<<setw(7)<<" 7."<<"Blood Group"<<endl;
    cout<<setw(7)<<" 8."<<"Admission Number"<<endl;
    cout<<setw(7)<<" 9."<<"Admission Date"<<endl;
    cout<<setw(7)<<"10."<<"Date of Birth"<<endl;
    cout<<setw(7)<<"11."<<"Address"<<endl;
    cout<<setw(7)<<"12."<<"Cast Category"<<endl;
    cout<<setw(7)<<"13."<<"Phone Number"<<endl;
    cout<<setw(7)<<"14."<<"Email ID"<<endl;
    cout<<setw(7)<<"15."<<"Height & Weight"<<endl;
    cout<<setw(7)<<"16."<<"Student's Unique ID"<<endl;
    cout<<setw(7)<<"17."<<"Password (Max Length 10)"<<endl;
    cout<<setw(7)<<"18."<<"Result of 10th or 12th (If Passed Out Type Class \"13\")"<<endl;
    cout<<setw(7)<<" 0."<<"Stop Editing"<<endl;
    cout<<setw(7)<<":::"<<"Enter Your Choice Number: ";
    cin>>Choice;
    system("cls");
    display();
    switch(Choice)
    {
        case 1: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Student's Name"<<setw(17)<<":> ";gets(name);
                while(name[0]=='\0'){gotoXY(38,8);gets(name);}
                strcpy(temp_name,"name");
                strcpy(name,upper_case(name));
                strcpy(name,underscore(name));
                make_file(temp_name,name);
                edit_data();
                break;

        case 2: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Class"<<setw(26)<<":> ";gets(clas);
                while(clas[0]=='\0'||digit(clas)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(clas);}

                if(CharToNum(clas)<13){
                cout<<setw(7)<<"|> "<<"Section"<<setw(24)<<":> ";gets(section);
                while(section[0]=='\0'||alpha(section)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(section);}
                strcpy(section,upper(section));}

                if(CharToNum(clas)>10){
                cout<<setw(7)<<"|> "<<"Result of 10th(in %age)"<<setw(8)<<":> ";gets(char_result_10);
                while(char_result_10[0]=='\0'||result_temp(char_result_10)>0)
                {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(char_result_10);}
                strcpy(temp_char_result_10,"char_result_10");
                make_file(temp_char_result_10,char_result_10);}

                if(CharToNum(clas)>12){
                cout<<setw(7)<<"|> "<<"Result of 12th(in %age)"<<setw(8)<<":> ";gets(char_result_12);
                while(char_result_12[0]=='\0'||result_temp(char_result_12)>0)
                {gotoXY(38,10);cout<<setw(100)<<"";gotoXY(38,10);gets(char_result_12);}
                strcpy(temp_char_result_12,"char_result_12");
                make_file(temp_char_result_12,char_result_12);}

                if(CharToNum(clas)<10){
                char del[64];
                char temp[16];
                int i=0;
                strcpy(del,"Del /F /Q ");
                strcat(del,"database\\");
                strcat(del,unique_id);
                strcat(del,"_");
                strcpy(temp,birth_date);
                while(temp[i]!='\0')
                {
                    if(temp[i]=='/'){temp[i]='_';}
                    i++;
                }
                strcat(del,temp);
                strcat(del,"\\char_result_10.sdms");
                system(del);}

                if(CharToNum(clas)<12){
                char del[64];
                char temp[16];
                int i=0;
                strcpy(del,"Del /F /Q ");
                strcat(del,"database\\");
                strcat(del,unique_id);
                strcat(del,"_");
                strcpy(temp,birth_date);
                while(temp[i]!='\0')
                {
                    if(temp[i]=='/'){temp[i]='_';}
                    i++;
                }
                strcat(del,temp);
                strcat(del,"\\char_result_12.sdms");
                system(del);}

                if(CharToNum(clas)>12)
                {
                    strcpy(clas,"Passed_Out");
                    strcpy(section,"Passed_Out");
                }

                strcpy(temp_clas,"clas");
                make_file(temp_clas,clas);
                strcpy(temp_section,"section");
                make_file(temp_section,section);

                edit_data();
                break;

        case 3: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Roll Number"<<setw(20)<<":> ";gets(roll_number);
                while(roll_number[0]=='\0'||digit(roll_number)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(roll_number);}
                strcpy(temp_roll_number,"roll_number");
                make_file(temp_roll_number,roll_number);
                edit_data();
                break;

        case 4: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Father's Name"<<setw(18)<<":> ";gets(fathers_name);
                while(fathers_name[0]=='\0'){gotoXY(38,8);gets(fathers_name);}
                strcpy(temp_fathers_name,"fathers_name");
                strcpy(fathers_name,upper_case(fathers_name));
                strcpy(fathers_name,underscore(fathers_name));
                make_file(temp_fathers_name,fathers_name);
                edit_data();
                break;

        case 5: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Mother's Name"<<setw(18)<<":> ";gets(mothers_name);
                while(mothers_name[0]=='\0'){gotoXY(38,8);gets(mothers_name);}
                strcpy(temp_mothers_name,"mothers_name");
                strcpy(mothers_name,upper_case(mothers_name));
                strcpy(mothers_name,underscore(mothers_name));
                make_file(temp_mothers_name,mothers_name);
                edit_data();
                break;

        case 6: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Gender(M/F)"<<setw(20)<<":> ";gets(gender);
                while(gender_temp(gender[0])==1)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(gender);}
                strcpy(temp_gender,"gender");
                if(gender[0]=='m'||gender[0]=='M'){strcpy(gender,"Male");}
                else strcpy(gender,"Female");
                make_file(temp_gender,gender);
                edit_data();
                break;

        case 7: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Blood Group"<<setw(20)<<":> ";gets(blood_group);
                while(blood_group[0]=='\0'||blood_temp(blood_group)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(blood_group);}
                strcpy(temp_blood_group,"blood_group");
                strcpy(blood_group,upper(blood_group));
                make_file(temp_blood_group,blood_group);
                edit_data();
                break;

        case 8: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Admission Number"<<setw(15)<<":> ";gets(admission_number);
                while(admission_number[0]=='\0'||digit(admission_number)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(admission_number);}
                strcpy(temp_admission_number,"admission_number");
                make_file(temp_admission_number,admission_number);
                edit_data();
                break;

        case 9: cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Admission Date(DD/MM/YYYY)"<<setw(5)<<":> ";gets(admission_date);
                while(admission_date[0]=='\0'||date_temp(admission_date)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(admission_date);}
                strcpy(temp_admission_date,"admission_date");
                make_file(temp_admission_date,admission_date);
                edit_data();
                break;

        case 10:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";gets(birth_date);
                while(birth_date[0]=='\0'||date_temp(birth_date)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(birth_date);}
                frename();
                strcpy(temp_birth_date,"birth_date");
                make_file(temp_birth_date,birth_date);
                edit_data();
                break;

        case 11:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Address"<<setw(24)<<":> ";gets(address);
                while(address[0]=='\0'){gotoXY(38,8);gets(address);}
                strcpy(temp_address,"address");
                strcpy(address,upper_case(address));
                strcpy(address,underscore(address));
                make_file(temp_address,address);
                edit_data();
                break;

        case 12:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Category(SC/ST/OBC/GENERAL)"<<setw(4)<<":> ";gets(cast);
                while(cast[0]=='\0'||cast_temp(cast)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(cast);}
                strcpy(temp_cast,"cast");
                strcpy(cast,upper(cast));
                make_file(temp_cast,cast);
                edit_data();
                break;

        case 13:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Phone Number"<<setw(19)<<":> ";gets(phone_number);
                while(strlen(phone_number)<10||digit(phone_number)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(phone_number);}
                strcpy(temp_phone_number,"phone_number");
                make_file(temp_phone_number,phone_number);
                edit_data();
                break;

        case 14:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Email ID"<<setw(23)<<":> ";gets(email);
                while(strlen(email)<12||email_temp(email)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(email);}
                strcpy(temp_email,"email");
                make_file(temp_email,email);
                edit_data();
                break;

        case 15:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;

                cout<<setw(7)<<"|> "<<"Height(in Centimeters)"<<setw(9)<<":> ";gets(char_height);
                while(char_height[0]=='\0'||digit_temp(char_height)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(char_height);}

                cout<<setw(7)<<"|> "<<"Weight(in Kilograms)"<<setw(11)<<":> ";gets(char_weight);
                while(char_weight[0]=='\0'||digit_temp(char_weight)>0)
                {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(char_weight);}

                store_bmi();

                strcpy(temp_char_height,"char_height");
                make_file(temp_char_height,char_height);
                strcpy(temp_char_weight,"char_weight");
                make_file(temp_char_weight,char_weight);
                edit_data();
                break;

        case 16:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";gets(unique_id);
                while(unique_id[0]=='\0'||unique_id_temp(unique_id)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(unique_id);}
                frename();
                strcpy(temp_unique_id,"unique_id");
                make_file(temp_unique_id,unique_id);
                edit_data();
                break;

        case 17:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"Password (OF Length 8)"<<setw(9)<<":> ";
                strcpy(password,get_pass(password,8,38,8));
                store_password();
                edit_data();
                break;

        case 18:cout<<setfill(' ')<<endl;
                cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;
                cout<<setw(7)<<"|> "<<"First Enter Class"<<setw(14)<<":> ";gets(clas);
                while(clas[0]=='\0'||digit(clas)>0)
                {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(clas);}

                if(CharToNum(clas)>10){
                cout<<setw(7)<<"|> "<<"Result of 10th(in %age)"<<setw(8)<<":> ";gets(char_result_10);
                while(char_result_10[0]=='\0'||result_temp(char_result_10)>0)
                {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(char_result_10);}
                strcpy(temp_char_result_10,"char_result_10");
                make_file(temp_char_result_10,char_result_10);}

                if(CharToNum(clas)>12){
                cout<<setw(7)<<"|> "<<"Result of 12th(in %age)"<<setw(8)<<":> ";gets(char_result_12);
                while(char_result_12[0]=='\0'||result_temp(char_result_12)>0)
                {gotoXY(38,10);cout<<setw(100)<<"";gotoXY(38,10);gets(char_result_12);}
                strcpy(temp_char_result_12,"char_result_12");
                make_file(temp_char_result_12,char_result_12);}

                if(clas[0]=='1'&&clas[1]=='\0') {strcat(clas,"st");}
                else if(clas[0]=='2'&&clas[1]=='\0') {strcat(clas,"nd");}
                else if(clas[0]=='3'&&clas[1]=='\0') {strcat(clas,"rd");}
                else {if(CharToNum(clas)<13){strcat(clas,"th");}}

                if(CharToNum(clas)<10){
                char del[64];
                char temp[16];
                int i=0;
                strcpy(del,"Del /F /Q ");
                strcat(del,"database\\");
                strcat(del,unique_id);
                strcat(del,"_");
                strcpy(temp,birth_date);
                while(temp[i]!='\0')
                {
                    if(temp[i]=='/'){temp[i]='_';}
                    i++;
                }
                strcat(del,temp);
                strcat(del,"\\char_result_10.sdms");
                system(del);}

                if(CharToNum(clas)<12){
                char del[64];
                char temp[16];
                int i=0;
                strcpy(del,"Del /F /Q ");
                strcat(del,"database\\");
                strcat(del,unique_id);
                strcat(del,"_");
                strcpy(temp,birth_date);
                while(temp[i]!='\0')
                {
                    if(temp[i]=='/'){temp[i]='_';}
                    i++;
                }
                strcat(del,temp);
                strcat(del,"\\char_result_12.sdms");
                system(del);}

                if(CharToNum(clas)>12)
                {
                    strcpy(clas,"Passed_Out");
                    strcpy(section,"Passed_Out");
                }

                strcpy(temp_clas,"clas");
                make_file(temp_clas,clas);
                strcpy(temp_section,"section");
                make_file(temp_section,section);

                edit_data();
                break;

        case 0: cout<<"\n"<<setw(7)<<":::"<<" Entries Are Changed Successfully! :::";
                cout<<"\n\n\n";
                break;

        default:cout<<"\n"<<setw(7)<<":::::"<<" Invalid Choice! :::::";
                edit_data();
    }
}           // It is the End of Option 4

// It changes the Student Login Password
void student::forgot_password()         // It is the Starting of Option 5
{
    cout<<setfill(' ')<<endl;
    cout<<setw(7)<<""<<"Please Fill Up The Following Details Carefully"<<endl;

    cout<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> ";gets(unique_id);
    while(unique_id[0]=='\0'||unique_id_temp(unique_id)>0)
    {gotoXY(38,8);cout<<setw(100)<<"";gotoXY(38,8);gets(unique_id);}

    cout<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> ";gets(birth_date);
    while(birth_date[0]=='\0'||date_temp(birth_date)>0)
    {gotoXY(38,9);cout<<setw(100)<<"";gotoXY(38,9);gets(birth_date);}

    cout<<"\n"<<setw(5)<<":::::"<<" Enter The Master Password (OF Length 8) :> ";
    strcpy(mast_pass,get_pass(mast_pass,8,49,11));
    if(strcmp(mast_pass,"madebysp")==0)
    {
        system("cls");
        display();
        cout<<setfill(' ');
        cout<<"\n"<<setw(5)<<":::::"<<" Enter New Password (OF Length 8) :> ";
        strcpy(password,get_pass(password,8,42,7));
        store_password();
        cout<<"\n\nPassword changed Successfully!";
    }
    else cout<<"\n"<<setw(5)<<""<<"Incorrect Master Password! Contact the Software Developer for Help...";
    cout<<"\n\n\n";
    system("timeout 3");
}           // It is the End of Option 5

// It is to Change Font Size
void student::Font(int y)
{
    FONT Object;
    Object.Size=sizeof(Object);
    Object.FontSize.Y = y;
    Object.FontWeight = 700;
    wcscpy(Object.FaceName, L"Consolas");
    SetCurrentConsoleFontEx(Console, false, &Object);
}

// It Renames the Student Database
void student::frename()
{
    strcpy(fname,"database\\");
    strcat(fname,unique_id);
    strcat(fname,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(fname,temp);
    rename(fname_old,fname);
    strcpy(fname_old,fname);

    strcpy(fcode,"secured\\");
    strcat(fcode,unique_id);
    strcat(fcode,"_");
    strcat(fcode,temp);
    rename(fcode_old,fcode);
    strcpy(fcode_old,fcode);
}

// Checks whether a Character Array is a Alphabetical String or not
int student::alpha(char* ch)
{
    int i=0;
    int c=0;
    while(ch[i]!='\0')
    {
        if(ch[i]>='A'&&ch[i]<='Z')c=0;
        else if(ch[i]>='a'&&ch[i]<='z')c=0;
        else c++;
        if(c>0)break;
        i++;
    }
    return c;
}

// It checks whether the entered Blood Group is Valid or not
int student::blood_temp(char* ch)
{
    int i=0,k=0,l=0,c=1;
    l=strlen(ch);

    if(l<4){
    if(ch[1]=='b'||ch[1]=='B')k=1;
    if(k==1&&l==2){c++;}
    else
    while(ch[i]!='\0')
    {
        if(ch[1]=='\0'){c++;break;}
        if(i==0)
        switch(ch[0])
        {
            case 'a':c=0;break;
            case 'A':c=0;break;
            case 'b':c=0;break;
            case 'B':c=0;break;
            case 'o':c=0;break;
            case 'O':c=0;break;
            default :c++      ;
        }
        else if(i==1)
        switch(ch[1])
        {
            case '+':c=0;break;
            case '-':c=0;break;
            case 'b':c=0;break;
            case 'B':c=0;break;
            default :c++      ;
        }
        else
        switch(ch[2])
        {
            case '+':c=0;break;
            case '-':c=0;break;
            default :c++      ;
        }
        if(c>0)break;
        i++;
    }}
    return c;
}

// It checks whether the entered Cast is Valid or not
int student::cast_temp(char* ch)
{
    strcpy(ch,upper(ch));
    if(strcmp(ch,"SC")==0)return 0;
    else if(strcmp(ch,"ST")==0)return 0;
    else if(strcmp(ch,"OBC")==0)return 0;
    else if(strcmp(ch,"GENERAL")==0)return 0;
    else return 1;
}

// It converts a Numerical character array into a Numbers
float student::CharToNum(char* num)
{
    float a=0;
    int i,p,l,c;
    l=strlen(num);
    for(c=0;c<=l;c++){if(num[c]=='.')break;}
    i=0;p=1;
    while(num[i]!='\0')
    {
        switch(num[i])
        {
            case '1':if(i>c){a=a+(1/pow(10,p));p++;}
                     else a=(a*10)+1;break;
            case '2':if(i>c){a=a+(2/pow(10,p));p++;}
                     else a=(a*10)+2;break;
            case '3':if(i>c){a=a+(3/pow(10,p));p++;}
                     else a=(a*10)+3;break;
            case '4':if(i>c){a=a+(4/pow(10,p));p++;}
                     else a=(a*10)+4;break;
            case '5':if(i>c){a=a+(5/pow(10,p));p++;}
                     else a=(a*10)+5;break;
            case '6':if(i>c){a=a+(6/pow(10,p));p++;}
                     else a=(a*10)+6;break;
            case '7':if(i>c){a=a+(7/pow(10,p));p++;}
                     else a=(a*10)+7;break;
            case '8':if(i>c){a=a+(8/pow(10,p));p++;}
                     else a=(a*10)+8;break;
            case '9':if(i>c){a=a+(9/pow(10,p));p++;}
                     else a=(a*10)+9;break;
            case '0':if(i>c){p++;}else a=(a*10)+0;break;
                     default :;
        }
        i++;
    }
    return a;
}

// It checks whether the Entered Date is Valid or not
int student::date_temp(char* ch)
{
    if(ch[2]!='/'&&ch[5]!='/')return 1;

    char dd[3],mm[3],yyyy[5];
    int d,m,y,dmax;
    dd[0]=ch[0];
    dd[1]=ch[1];
    dd[2]='\0';
    if(digit(dd)==0){d=CharToNum(dd);}
    else return 1;
    if(d>31)return 1;
    mm[0]=ch[3];
    mm[1]=ch[4];
    mm[2]='\0';
    if(digit(mm)==0){m=CharToNum(mm);}
    else return 1;
    if(m>12)return 1;
    yyyy[0]=ch[6];
    yyyy[1]=ch[7];
    yyyy[2]=ch[8];
    yyyy[3]=ch[9];
    yyyy[4]='\0';
    if(digit(yyyy)==0){y=CharToNum(yyyy);}
    else return 1;
    if(y<1900)return 1;
    if(y>3000)return 1;

    if(m==1)dmax=31;
    else if(m==2){if(y%4==0)dmax=29;else dmax=28;}
    else if(m==3)dmax=31;
    else if(m==4)dmax=30;
    else if(m==5)dmax=31;
    else if(m==6)dmax=30;
    else if(m==7)dmax=31;
    else if(m==8)dmax=31;
    else if(m==9)dmax=30;
    else if(m==10)dmax=31;
    else if(m==11)dmax=30;
    else if(m==12)dmax=31;
    else return 1;

    if(d>dmax)return 1;
    return 0;
}

// Checks whether a Character Array is a Numerical String or not
int student::digit(char* ch)
{
    int i=0;
    int c=0;
    while(ch[i]!='\0')
    {
        if(ch[i]>='0'&&ch[i]<='9')c=0;
        else c=1;
        if(c>0)break;
        i++;
    }
    return c;
}

// It checks whether the Entered character array is a Floating Point Numbers or not
int student::digit_temp(char* ch)
{
    int i=0;
    int c=0;
    while(ch[i]!='\0')
    {
        switch(ch[i])
        {
            case '1':c=0;break;
            case '2':c=0;break;
            case '3':c=0;break;
            case '4':c=0;break;
            case '5':c=0;break;
            case '6':c=0;break;
            case '7':c=0;break;
            case '8':c=0;break;
            case '9':c=0;break;
            case '0':c=0;break;
            case '.':c=0;break;
            default :c++      ;
        }
        if(c>0)break;
        i++;
    }
    return c;
}

// It approximately checks whether the Entered Email ID is Valid or not
int student::email_temp(char* ch)
{
    int j,i,c=1,d=1;

    j=strlen(ch);
    i=1;
    while(i<6)
    {
        if(ch[j-i]=='.'){c=0;break;}
        i++;
    }
    i=1;
    while(i<16)
    {
        if(ch[j-i]=='@'){d=0;break;}
        i++;
    }
    if(c==0&&d==0)return 0;
    else return 1;
}

// It checks whether the Entered Gender is Valid or not
int student::gender_temp(char ch)
{
    if(ch=='m')return 0;
    else if(ch=='M')return 0;
    else if(ch=='f')return 0;
    else if(ch=='F')return 0;
    else return 1;
}

// It Reads the Student Data Files From their Locations
char* student::get_file(char* ch)
{
    char spell[64];
    strcpy(spell,"database\\");
    strcat(spell,unique_id);
    strcat(spell,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(spell,temp);
    strcat(spell,"\\");
    strcat(spell,ch);
    strcat(spell,".sdms");
    ifstream file_in;
    file_in.open(spell);
    file_in>>ch;
    file_in.close();
    return ch;
}

// It helps to Input Passwords Securely by Display "*" while inputting Passwords
char* student::get_pass(char* pass,int n,int x,int y)
{
        int i=0;
        while(i<n)
        {
            pass[i]=_getch();           //NOT getch(); but _getch();
            cout<<'*';
            while(pass[i]=='\b')
            {
                if(i>0){--x;--i;}
                gotoXY(x,y);    //get back to previous coordinate
                cout<<setw(2)<<"";  //clear the space
                gotoXY(x,y);    //and again come back
                //now again get pswrd
                pass[i]=_getch();       //NOT getch() but _getch();
                cout<<'*';
            }

            if(i==n-1)
                pass[n]='\0';

            x++;
            i++;
        }
        return pass;
}

// It Merge All The Information Of Student To A Single Document
void student::MakeDocument()
{
    // Storing Names of File as before
    strcpy(temp_name,"name");
    strcpy(temp_fathers_name,"fathers_name");
    strcpy(temp_mothers_name,"mothers_name");
    strcpy(temp_clas,"clas");
    strcpy(temp_section,"section");
    strcpy(temp_roll_number,"roll_number");
    strcpy(temp_admission_date,"admission_date");
    strcpy(temp_admission_number,"admission_number");
    strcpy(temp_blood_group,"blood_group");
    strcpy(temp_gender,"gender");
    strcpy(temp_address,"address");
    strcpy(temp_cast,"cast");
    strcpy(temp_phone_number,"phone_number");
    strcpy(temp_email,"email");
    strcpy(temp_char_height,"char_height");
    strcpy(temp_char_weight,"char_weight");
    strcpy(temp_char_result_10,"char_result_10");
    strcpy(temp_char_result_12,"char_result_12");
    strcpy(temp_bmi,"bmi");
    strcpy(temp_unique_id,"unique_id");

    // Reading Student Data from already stored Data
    strcpy(name,get_file(temp_name));
    strcpy(fathers_name,get_file(temp_fathers_name));
    strcpy(mothers_name,get_file(temp_mothers_name));
    strcpy(clas,get_file(temp_clas));
    strcpy(section,get_file(temp_section));
    strcpy(roll_number,get_file(temp_roll_number));
    strcpy(admission_date,get_file(temp_admission_date));
    strcpy(admission_number,get_file(temp_admission_number));
    strcpy(blood_group,get_file(temp_blood_group));
    strcpy(gender,get_file(temp_gender));
    strcpy(address,get_file(temp_address));
    strcpy(cast,get_file(temp_cast));
    strcpy(phone_number,get_file(temp_phone_number));
    strcpy(email,get_file(temp_email));
    strcpy(char_height,get_file(temp_char_height));
    strcpy(char_weight,get_file(temp_char_weight));
    if(CharToNum(clas)>10){
    strcpy(char_result_10,get_file(temp_char_result_10));}
    if(CharToNum(clas)>12){
    strcpy(char_result_12,get_file(temp_char_result_12));}
    strcpy(char_bmi,get_file(temp_bmi));
    strcpy(unique_id,get_file(temp_unique_id));
    bmi=CharToNum(char_bmi);

    // Replacing the "_" with " "
    strcpy(name,no_underscore(name));
    strcpy(fathers_name,no_underscore(fathers_name));
    strcpy(mothers_name,no_underscore(mothers_name));
    strcpy(address,no_underscore(address));

    if(strcmp(clas,"Passed_Out")==0)
    {
        strcpy(clas,"Passed Out");
        strcpy(section,"Passed Out");
    }

    char spell[64];
    strcpy(spell,"database\\");
    strcat(spell,unique_id);
    strcat(spell,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(spell,temp);
    strcat(spell,"\\Document.txt");
    ofstream file_out(spell);
    file_out<<setfill(' ')<<endl;
    file_out<<setw(7)<<"|> "<<"Student's Name"<<setw(17)<<":> "<<name<<endl;
    file_out<<setw(7)<<"|> "<<"Class"<<setw(26)<<":> "<<clas<<endl;
    file_out<<setw(7)<<"|> "<<"Section"<<setw(24)<<":> "<<section<<endl;
    file_out<<setw(7)<<"|> "<<"Roll Number"<<setw(20)<<":> "<<roll_number<<endl;
    file_out<<setw(7)<<"|> "<<"Father's Name"<<setw(18)<<":> "<<fathers_name<<endl;
    file_out<<setw(7)<<"|> "<<"Mother's Name"<<setw(18)<<":> "<<mothers_name<<endl;
    file_out<<setw(7)<<"|> "<<"Gender(M/F)"<<setw(20)<<":> "<<gender<<endl;
    file_out<<setw(7)<<"|> "<<"Blood Group"<<setw(20)<<":> "<<blood_group<<endl;
    file_out<<setw(7)<<"|> "<<"Admission Number"<<setw(15)<<":> "<<admission_number<<endl;
    file_out<<setw(7)<<"|> "<<"Admission Date(DD/MM/YYYY)"<<setw(5)<<":> "<<admission_date<<endl;
    file_out<<setw(7)<<"|> "<<"Date of Birth(DD/MM/YYYY)"<<setw(6)<<":> "<<birth_date<<endl;
    file_out<<setw(7)<<"|> "<<"Address"<<setw(24)<<":> "<<address<<endl;
    file_out<<setw(7)<<"|> "<<"Category(SC/ST/OBC/GENERAL)"<<setw(4)<<":> "<<cast<<endl;
    file_out<<setw(7)<<"|> "<<"Phone Number"<<setw(19)<<":> "<<phone_number<<endl;
    file_out<<setw(7)<<"|> "<<"Email ID"<<setw(23)<<":> "<<email<<endl;
    file_out<<setw(7)<<"|> "<<"Height(in Centimeters)"<<setw(9)<<":> "<<char_height<<endl;
    file_out<<setw(7)<<"|> "<<"Weight(in Kilograms)"<<setw(11)<<":> "<<char_weight<<endl;
    file_out<<setw(7)<<"|> "<<"Student's Unique ID"<<setw(12)<<":> "<<unique_id<<endl;
    file_out<<setw(7)<<"|> "<<"BMI(Body Mass Index)"<<setw(11)<<":> "<<char_bmi<<" ";
    if(bmi>0&&bmi<18.5){file_out<<"(UNDER-WEIGHT)\n";}
    else if(bmi>=18.5&&bmi<25){file_out<<"(HEALTHY)\n";}
    else if(bmi>=25&&bmi<30){file_out<<"(OVER-WEIGHT)\n";}
    else {file_out<<"(OBESE)\n";}
    if(CharToNum(clas)>10){
    file_out<<setw(7)<<"|> "<<"Result of 10th(in %age)"<<setw(8)<<":> "<<char_result_10<<endl;}
    if(CharToNum(clas)>12){
    file_out<<setw(7)<<"|> "<<"Result of 12th(in %age)"<<setw(8)<<":> "<<char_result_12<<endl;}
    file_out.close();
}

// It Stores the Student Data Files to the their Locations
void student::make_file(char* ch,char* chr)
{
    char spell[64];
    strcpy(spell,"database\\");
    strcat(spell,unique_id);
    strcat(spell,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(spell,temp);
    strcat(spell,"\\");
    strcat(spell,ch);
    strcat(spell,".sdms");
    ofstream file_out;
    file_out.open(spell);
    file_out<<chr;
    file_out.close();
}

// It Replaces the "_" with " "
char* student::no_underscore(char* spell)
{
    int i=0;
    while(spell[i]!='\0')
    {
        if(spell[i]=='_')spell[i]=' ';
        i++;
    }
    return spell;
}

// It checks whether the Entered Result is Valid or not
int student::result_temp(char* ch)
{
    if(digit(ch)==0)
    {
        if(CharToNum(ch)>=0&&CharToNum(ch)<=100)return 0;
    }
    else return 1;
}

// It is to store BMI
void student::store_bmi()
{
    // Calculating BMI(Body Mass Index)
    height=CharToNum(char_height);
    weight=CharToNum(char_weight);
    height/=100;
    bmi=weight/pow(height,2);

    // Storing BMI
    char spell[64];
    strcpy(spell,"database\\");
    strcat(spell,unique_id);
    strcat(spell,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(spell,temp);
    strcat(spell,"\\");
    strcat(spell,"bmi");
    strcat(spell,".sdms");
    ofstream file_out;
    file_out.open(spell);
    file_out<<bmi;
    file_out.close();
}

// It Stores the Password to the Secured Location
void student::store_password()
{
    if(!mkdir("secured"));
    strcpy(fcode,"secured\\");
    strcat(fcode,unique_id);
    strcat(fcode,"_");
    char temp[16];
    int i=0;
    strcpy(temp,birth_date);
    while(temp[i]!='\0')
    {
        if(temp[i]=='/'){temp[i]='_';}
        i++;
    }
    strcat(fcode,temp);
    strcat(fcode,".sdms");
    ofstream file_out(fcode);
    file_out<<password;
    file_out.close();
}

// It Replaces the " " with "_"
char* student::underscore(char* spell)
{
    int i=0;
    while(spell[i]!='\0')
    {
        if(spell[i]==' ')spell[i]='_';
        i++;
    }
    return spell;
}

// It checks whether the Entered Unique ID is Valid or not
int student::unique_id_temp(char* ch)
{

    int i=0,l=0,c=0;
    l=strlen(ch);
    if(l<15)c++;
    else
    while(ch[i]!='\0')
    {
        if(ch[i]>='0'&&ch[i]<='9')c=0;
        else c++;
        if(c>0)break;
        i++;
    }
    return c;
}

// It converts all the Letters of the Sting to Capital Letters
char* student::upper(char* spell)
{
    int len,i=0;
    len=strlen(spell);
    while(spell[i]!='\0')
    {
        spell[i]=toupper(spell[i]);
        i++;
    }
    return spell;
}

// It converts only the first Letters of the Sting to Capital Letters
char* student::upper_case(char* spell)
{
    int len,i=0;
    len=strlen(spell);
    spell[0]=toupper(spell[0]);
    while(spell[i]!='\0')
    {
        if(spell[i-1]==' ')spell[i]=toupper(spell[i]);
        i++;
    }
    return spell;
}
//::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::THE::END:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
//:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

